<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">throwException</value>
  <value name="encodeutf8">true</value>
  <value name="body">Ly8gcGlwZWxpbmUNCklEYXRhQ3Vyc29yIHBpcGVsaW5lQ3Vyc29yID0gcGlwZWxpbmUuZ2V0Q3Vy
c29yKCk7DQoJU3RyaW5nCW1lc3NhZ2UgPSBJRGF0YVV0aWwuZ2V0U3RyaW5nKCBwaXBlbGluZUN1
cnNvciwgIm1lc3NhZ2UiICk7DQpwaXBlbGluZUN1cnNvci5kZXN0cm95KCk7DQoNCi8vIHBpcGVs
aW5lDQp0aHJvdyBuZXcgU2VydmljZUV4Y2VwdGlvbihtZXNzYWdlKTs=</value>
</Values>
