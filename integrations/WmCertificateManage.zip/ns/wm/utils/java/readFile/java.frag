<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">readFile</value>
  <value name="encodeutf8">true</value>
  <value name="body">Ly8gcGlwZWxpbmUNCklEYXRhQ3Vyc29yIHBpcGVsaW5lQ3Vyc29yID0gcGlwZWxpbmUuZ2V0Q3Vy
c29yKCk7DQoJU3RyaW5nCXBhdGggPSBJRGF0YVV0aWwuZ2V0U3RyaW5nKCBwaXBlbGluZUN1cnNv
ciwgInBhdGgiICk7DQpwaXBlbGluZUN1cnNvci5kZXN0cm95KCk7DQoNCiBieXRlW10gY29udGVu
dDsNCnRyeSB7DQoJY29udGVudCA9IEZpbGVzLnJlYWRBbGxCeXRlcyhQYXRocy5nZXQocGF0aCkp
Ow0KCUlEYXRhQ3Vyc29yIHBpcGVsaW5lQ3Vyc29yXzEgPSBwaXBlbGluZS5nZXRDdXJzb3IoKTsN
CglJRGF0YVV0aWwucHV0KCBwaXBlbGluZUN1cnNvcl8xLCAiY29udGVudCIsIGNvbnRlbnQgKTsN
CglwaXBlbGluZUN1cnNvcl8xLmRlc3Ryb3koKTsNCn0gY2F0Y2ggKElPRXhjZXB0aW9uIGUpIHsN
Cgl0aHJvdyBuZXcgU2VydmljZUV4Y2VwdGlvbihlKTsNCn0=</value>
</Values>
