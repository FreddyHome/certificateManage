package wm.utils;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
// --- <<IS-END-IMPORTS>> ---

public final class java

{
	// ---( internal utility methods )---

	final static java _instance = new java();

	static java _newInstance() { return new java(); }

	static java _cast(Object o) { return (java)o; }

	// ---( server methods )---




	public static final void mvFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(mvFile)>> ---
		// @sigtype java 3.5
		// [i] field:0:required oldFilePath
		// [i] field:0:required newFilePath
		// [o] field:0:required status
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	oldFilePath = IDataUtil.getString( pipelineCursor, "oldFilePath" );
			String	newFilePath = IDataUtil.getString( pipelineCursor, "newFilePath" );
		pipelineCursor.destroy();
		
		
		File source = new File(oldFilePath);
		File target = new File(newFilePath);
		
		Boolean status = source.renameTo(target);
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "status", String.valueOf(status) );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void readFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(readFile)>> ---
		// @sigtype java 3.5
		// [i] field:0:required path
		// [o] object:0:required content
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	path = IDataUtil.getString( pipelineCursor, "path" );
		pipelineCursor.destroy();
		
		 byte[] content;
		try {
			content = Files.readAllBytes(Paths.get(path));
			IDataCursor pipelineCursor_1 = pipeline.getCursor();
			IDataUtil.put( pipelineCursor_1, "content", content );
			pipelineCursor_1.destroy();
		} catch (IOException e) {
			throw new ServiceException(e);
		}
		// --- <<IS-END>> ---

                
	}



	public static final void throwException (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(throwException)>> ---
		// @sigtype java 3.5
		// [i] field:0:required message
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	message = IDataUtil.getString( pipelineCursor, "message" );
		pipelineCursor.destroy();
		
		// pipeline
		throw new ServiceException(message);
		// --- <<IS-END>> ---

                
	}



	public static final void writeFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(writeFile)>> ---
		// @sigtype java 3.5
		// [i] field:0:required filePath
		// [i] object:0:required content
		// [o] field:0:required status
		// [o] field:0:required message
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	filePath = IDataUtil.getString( pipelineCursor, "filePath" );
			Object	content = IDataUtil.get( pipelineCursor, "content" );
		pipelineCursor.destroy();
		
		String status = "true";
		String message = "success.";
		try {
			Files.write(Paths.get(filePath), (byte[])content);
		} catch (IOException e) {
			message = e.getMessage();
			status = "false";
		}
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "status", status );
		IDataUtil.put( pipelineCursor_1, "message", message );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}
}

